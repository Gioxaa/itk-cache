<?php
defined('MOODLE_INTERNAL') || die();
$plugin->component = 'local_rce';
$plugin->version   = 2026110900;
$plugin->requires  = 2018050800;
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.0';
