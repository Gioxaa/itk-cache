<?php
$string['pluginname'] = 'Cache helper';
